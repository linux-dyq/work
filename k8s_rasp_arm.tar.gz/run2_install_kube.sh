#!/bin/bash
# 安装顺序为先 kubelet kubectl ,再kubeadm
WORK_DIR='/k8s'
cd  $WORK_DIR
KUBELET_DEB="`ls | grep kubelet`"
KUBECTL_DEB="`ls | grep kubectl`"
KUBEADM_DEB="`ls | grep kubeadm`"

dpkg  -i $KUBELET_DEB
dpkg  -i $KUBECTL_DEB
dpkg  -i $KUBEADM_DEB

