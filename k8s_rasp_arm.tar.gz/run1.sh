DOCKER_VERSION=19
K8S_COMPATIBLE='1.17'
K8S_REPO='http://mirrors.aliyun.com/kubernetes/apt/'
K8S_DOCKER='apiserver,controller manager,scheduler,kube-proxy,etcd,coredns,pause'
KUBEADM117='http://mirrors.aliyun.com/kubernetes/apt/pool/kubeadm_1.17.0-00_arm64_fdd460e883413a9cd8f03e70e2e80849169b3ac65822ab637b996dbfc6616c69.deb'
KUBECTL117='http://mirrors.aliyun.com/kubernetes/apt/pool/kubectl_1.17.0-00_arm64_1c6435d655cd19a69dec90f9132a13ad5db34f1824330b35b48d1e19aa7fda48.deb'
KUBELET117='http://mirrors.aliyun.com/kubernetes/apt/pool/kubelet_1.17.1-00_arm64_5df2c0d532fa791ad12c85822f398726ceecb273778993bbb6ef301ba6f4f16a.deb'
KUBECNI075='http://mirrors.aliyun.com/kubernetes/apt/pool/kubernetes-cni_0.7.5-00_arm64_16f686a176ee62fc4f960fd4b272e5e26c73fcced8bd1f8ce9a68a54b2b07e28.deb'
ETCD_VER=''
FLANNEL_VER='0.11.0'

#  ----
WORK_DIR='/k8s'
cd  $WORK_DIR
wget $KUBEADM117
wget $KUBECTL117
wget $KUBELET117
wget $KUBECNI075
