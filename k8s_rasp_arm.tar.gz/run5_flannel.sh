#!/bin/bash
docker pull quay.io/coreos/flannel:v0.11.0-amd64
